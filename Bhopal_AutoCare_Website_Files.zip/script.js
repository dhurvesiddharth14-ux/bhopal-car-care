document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Booking Submitted! We will contact you shortly.');
});
